<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="files/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;500;700&display=swap" rel="stylesheet">
    <title>TV ZST</title>
</head>
<body>
<script>
    //ladowanie zdjec
<?php
function returnimages($dirname="./files/imgs/") {
    $pattern="/([a-z\-_0-9\/\:\.]*\.(jpg|jpeg|png|gif))/i"; 
    $files = array();
    $curimage=0;
    if($handle = opendir($dirname)) {
        while(false !== ($file = readdir($handle))){
            if(preg_match($pattern, $file)){ 
                echo 'galleryarray['.$curimage.']="'.$file .'";';
                $curimage++;
            }
        }
        closedir($handle);
    }
    return($files);
}
echo 'let galleryarray=[];'; 
returnimages() 
?>
</script>
<div class="wrapper">
<div class="main-content">
    <div class="top">
        <div class="top-side">
            <div class="top-side-l"> 
                DO WAKACJI POZOSTAŁO:
                <div class="timer2"></div>
                <div class="weeks">40 tygodni</div>
            </div>
          
        </div>
        <div class="top-center">  
            <div class="date"></div>
            <div class="timer"><?php echo date("Y-m-d H:i:s") ?></div>
            <div class="day"></div>
        </div>
        <div class="top-side">
            <div class="top-side-r"> 
                <div class="to-end">
                    <div class="st">zostało jeszcze</div>
                    <div id="percent">100%</div>
                    <div class="school-year">roku szkolnego</div>
                </div>
            </div>
        </div>
        <div class="clock-wrapper">
            <div class="clock">
                <div class="minutes"></div>
                <div class="hours"></div>
                <div class="seconds"></div>
                <div class="circle"></div>
            </div>
        </div>
    </div>
    <div class="bottom">
        <div class="bottom-right">
            <div class="info-header">Informacja:</div>
                <?php
				
                    $dsn = "mysql:host=localhost;dbname=zstgrudz_tv";
                    $user = "zstgrudz_tv";
                    $pass = "ZST-tv-Grudzi@dz";
					try {
                        $pdo = new PDO($dsn, $user, $pass);
                        $stm = $pdo->query("SELECT * FROM komunikaty where date >".'"'.date("Y-m-d H:i:s").'"'." order by postid desc");
                        $rows = $stm->fetchAll(PDO::FETCH_NUM);
                        if($rows){
                            $rowNumber =1;
                            foreach($rows as $row) {
                                echo '<div class="info" style="display:none;">';
                                echo '<b>'.$rowNumber.") ".'</b>'.$row[1];
                                echo '</div>';
                                $rowNumber++;
                            }
                        }else{
                            echo '<div class="info" style="display:none;">';
                            echo 'Brak komunikatów :)';
                            echo '</div>';
                        }
					} catch (PDOException $e) {
						echo 'Connection failed: ' . $e->getMessage();
					}
				?>
        </div>
    </div>
    </div>
    <div class="second-content">
        <div class="immg"></div>
    </div>
    </div>
    <script src="files/main.js"></script>
</body>
</html>



