window.addEventListener('load', function () {
  

//______TU ZMIENIAC______
const rozpoczecieRoku = '2020-09-01 00:00';
const zakonczenieRoku = '2021-06-25 00:00';
const urlzdjec = "./files/imgs/";
const urlbg = "./files/backgrounds/";
//tla losowane sa z puli od 1 do n i rozszerzenie tylko jpg | 1.jpg 2.jpg .... n.jpg 
const ilosc_bg = 8; // [1-8].jpg


const moveTime = (s, m, h, d, ile, k) => {
  s = parseInt(s) + parseInt(ile);
  if (s >= 60) {
    m = parseInt(m) + parseInt(s / 60);
    s = s % 60;
  } else if (s < 0) {
    m = parseInt(m) + parseInt(s / 60 - 1);
    s = 60 + (s % 60);
  }
  if (m >= 60) {
    h = parseInt(h) + parseInt(m / 60);
    m = m % 60;
  } else if (m < 0) {
    h = parseInt(h) + parseInt(m / 60 - 1);
    m = 60 + (m % 60);
  }
  if (h >= 24) {
    d = parseInt(d) + parseInt(h / 24);
    h = h % 24;
  } else if (h < 0) {
    d = parseInt(d) + parseInt(h / 24 - 1);
    h = 24 + (h % 24);
  }
  if (d < 0 && k) {
    s = 0;
    m = 0;
    h = 0;
    d = 0;
    clearInterval(countDownInter);
  }
  return [s, m, h, d];
};
const dateModify = (a) => (a = parseInt(a) < 10 ? `0${parseInt(a)}` : a);

const dayMod = (a) => {
  const ds = ['Niedziela', 'Poniedziałek', 'Wtorek', 'Środa', 'Czwartek', 'Piątek', 'Sobota'];
  return ds[a];
};
//Data
class Timer {
  constructor(a) {
    const date = new Date(a);
    this.year = date.getFullYear();
    this.month = dateModify(date.getMonth() + 1);
    this.day = dateModify(date.getDate());
    this.hours = dateModify(date.getHours());
    this.minutes = dateModify(date.getMinutes());
    this.seconds = dateModify(date.getSeconds());
    this.dayname = date.getDay();
  }
}
//Odliczanie
class CountDown {
  constructor(a, b) {
    this.now = new Date(a).getTime();
    this.dateToHoliday = new Date(b).getTime();
    const t = this.dateToHoliday - this.now;
    this.d = Math.floor(t / (1000 * 60 * 60 * 24));
    this.h = Math.floor((t % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    this.m = Math.floor((t % (1000 * 60 * 60)) / (1000 * 60));
    this.s = Math.floor((t % (1000 * 60)) / 1000);
    this.w = Math.floor(t / (1000 * 60 * 60 * 24 * 7));
  }
}
let todayDate = document.querySelector('.timer').textContent;
let Maintimer = new Timer(document.querySelector('.timer').textContent);
let HolidayCountdown = new CountDown(document.querySelector('.timer').textContent, zakonczenieRoku);

let timer = document.querySelector('.timer');
let date = document.querySelector('.date');
let dayName = document.querySelector('.day');

let { day, month, year, hours, minutes, seconds, dayname } = Maintimer; //Destrukturyzacja obiektu Maintimer
timer.textContent = `${hours}:${minutes}:${seconds}`;
date.textContent = `${day}.${month}.${year}r.`;
dayName.textContent = dayMod(dayname);

let timer2 = document.querySelector('.timer2');
let weeks = document.querySelector('.weeks');
let { d, h, m, s, w } = HolidayCountdown; //Destrukturyzacja obiektu HolidayCountdown
timer2.textContent = `${d}dni ${h}h ${m}min ${s}s`;
weeks.textContent = `${w} tygodni`;

//Zegar analogowy
let clock = document.querySelector('.clock');

let hc = document.querySelector('.hours');
let mc = document.querySelector('.minutes');
let sc = document.querySelector('.seconds');

const apply = () => {
  hd = 30 * hours - 90;
  md = 6 * minutes - 90;
  sd = 6 * seconds - 90;

  hc.style.transform = `rotate(${hd}deg)`;
  mc.style.transform = `rotate(${md}deg)`;
  sc.style.transform = `rotate(${sd}deg)`;
};

//Ilośc % do zakończenia roku
const Percent = (e, t, n) => {
  var o,
    i = new Date(),
    u = e.getTime() - t.getTime(),
    d = e.getTime() - i.getTime();
  delete i,
    d < 0
      ? (document.getElementById(n).innerHTML = '')
      : ((o = ''),
        (o += ((d / u) * 100).toFixed(4) + ' %'),
        (document.getElementById(n).innerHTML = o),
        setTimeout(function () {
          Percent(e, t, n);
        }, 1e3));
};
Percent(new Date(zakonczenieRoku), new Date(rozpoczecieRoku), 'percent');
apply();

let timerInter = setInterval(() => {
  let newMainTimer = moveTime(seconds, minutes, hours, day, 1);
  seconds = dateModify(newMainTimer[0]);
  minutes = dateModify(newMainTimer[1]);
  hours = dateModify(newMainTimer[2]);
  day = dateModify(newMainTimer[3]);
  timer.textContent = `${hours}:${minutes}:${seconds}`;
  apply();
}, 1000);

let countDownInter = setInterval(() => {
  let newHolidayCountdown = moveTime(s, m, h, d, -1, 1);
  s = newHolidayCountdown[0];
  m = newHolidayCountdown[1];
  h = newHolidayCountdown[2];
  d = newHolidayCountdown[3];
  timer2.textContent = `${d}dni ${h}h ${m}min ${s}s`;
}, 1000);

//Zmiana komunikatów
const komlast = document.querySelectorAll('.info').length - 1;
const komelem = document.querySelectorAll('.info');
let komstart = 0;
const komSlider = (a) => {
  komelem.forEach((e) => {
    e.style.display = 'none';
  });
  komelem[a].style.display = 'block';
  if (a == komlast) a = -1;
  setTimeout(() => {
    komSlider(a + 1);
  }, 30000);
};

if (komlast >= 1) {
  komSlider(komstart);
} else if (komlast == 0) {
  komelem[0].style.display = 'block';
}
//losowanie tla strony
document.querySelector('.main-content').style.background= `url('${urlbg}${Math.ceil(Math.random()*ilosc_bg)}.jpg') no-repeat center center / cover`;
for(let i=0;i<100;i++){
  console.log(Math.ceil(Math.random()*ilosc_bg));
}

//Animacja chowania i pokazywania paska
let topAn = document.querySelector('.top');
let bottomAn = document.querySelector('.bottom');
let clockWrapperAn = document.querySelector('.clock-wrapper');
let second = document.querySelector('.second-content');
let immg = document.querySelector('.immg');

const slide1 = () => {
  topAn.style.height = '100vh';
  bottomAn.style.height = '0';
  clockWrapperAn.style.top = '50%';
  clockWrapperAn.style.transform = 'translate(-50%,-50%)';
  setTimeout(() => {
    slide2();
  }, 15000);
};
const slide2 = () => {
  topAn.style.height = '50vh';
  bottomAn.style.height = '50vh';
  clockWrapperAn.style.top = '0';
  clockWrapperAn.style.transform = 'translateX(-50%)';
  setTimeout(() => {
    slide1();
  }, 15000);
};

//Slider zdjec
let imagesLastElem = galleryarray.length-1;
let currentImage = 0;
const zdjan1 = () => {
  second.style.transform = 'translateX(-0%)';
  setTimeout(() => {
      immg.style.background =   `url("${urlzdjec}${galleryarray[currentImage]}") no-repeat center center / contain`;
      currentImage++;
      if(currentImage > imagesLastElem) currentImage=0;
  }, 2000);
  setTimeout(() => {
    zdjan2();
  }, 25000);
};
const zdjan2 = () => {
  second.style.transform = 'translateX(-100%)';
  setTimeout(() => {
    zdjan1();
  }, 8000);
};
zdjan1();
slide2();

})
